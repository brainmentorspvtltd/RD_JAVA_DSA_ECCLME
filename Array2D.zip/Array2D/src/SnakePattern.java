public class SnakePattern {
    public static void main(String[] args) {
        int arr[][] = {{1,2,3},{4,5,6},{7,8,9}};
		for (int i = 0; i < arr.length; i++) 
        { 
            // If current row is even, print from 
            // left to right 
            if (i % 2 == 0) 
            { 
                for (int j = 0; j < arr[0].length; j++) 
                    System.out.print(arr[i][j] +" "); 
            // If current row is odd, print from 
            // right to left 
            } 
            else
            { 
                for (int j = arr[0].length - 1; j >= 0; j--) 
                    System.out.print(arr[i][j] +" ");
            } 
        }
    }
}
